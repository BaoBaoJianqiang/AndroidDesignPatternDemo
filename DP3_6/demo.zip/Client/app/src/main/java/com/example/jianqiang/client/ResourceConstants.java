package com.example.jianqiang.client;

public interface ResourceConstants {

    interface LayoutResource {
    }
}
